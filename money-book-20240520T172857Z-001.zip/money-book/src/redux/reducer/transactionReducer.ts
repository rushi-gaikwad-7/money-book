import { initStateType } from "../../types/redux.types";
import {
  ADD_TRANSACTION,
  FILTER_TRANSACTION,
  GET_TRANSACTION,
} from "../actions/transaction.action";

const initState: initStateType = {
  Transactions: [],
  error: false,
  loading: true,
  dashboard: {
    income: 0,
    investment: 0,
    expenditure: 0,
    current_balance: 0,
  },
};

export const TransactionReducer = (
  state = initState,
  { type, payload }: any
) => {
  switch (type) {
    case GET_TRANSACTION: {
      return {
        ...state,
        ...payload,
      };
    }
    case ADD_TRANSACTION: {
      return {
        ...state,
        ...payload,
      };
    }
    case FILTER_TRANSACTION: {
      return {
        ...state,
        ...payload,
      };
    }

    default: {
      return state;
    }
  }
};
