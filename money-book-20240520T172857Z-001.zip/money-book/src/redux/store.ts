import { applyMiddleware, legacy_createStore  } from "redux";
import thunk from "redux-thunk";
import { TransactionReducer } from "./reducer/transactionReducer";

export const Store = legacy_createStore(TransactionReducer, applyMiddleware(thunk));
