import axios from "axios";
import { resType, TransactionObj } from "../../types/transaction.types";

// ACTION TYPES

export const ADD_TRANSACTION = "ADD_TRANSACTION";
export const GET_TRANSACTION = "GET_TRANSACTION";
export const FILTER_TRANSACTION = "FILTER_TRANSACTION";

//ACTIONS

export const addNewTransaction =
  (payload: TransactionObj, notify: Function) => async (dispatch: any) => {
    try {
      const res = await axios.post(
        "https://json-mock-server8.herokuapp.com/Transactions",
        { ...payload, Date: new Date() }
      );
      notify("Your transaction is added successfully");
      dispatch(getTransactions());
    } catch (e) {
      notify("transaction failed");
    }
  };

export const getTransactions = () => async (dispatch: any) => {
  try {
    const res = await axios.get(
      "https://json-mock-server8.herokuapp.com/Transactions"
    );

    let dashboard = {
      income: 0,
      investment: 0,
      expenditure: 0,
      current_balance: 0,
    };

    res.data.map((el: resType): void => {
      if (el.TransactionType === "income") {
        dashboard.income += Number(el.Amount);
      } else if (el.TransactionType === "investment") {
        dashboard.investment += Number(el.Amount);
      } else {
        dashboard.expenditure += Number(el.Amount);
      }
    });

    dashboard.current_balance =
      dashboard.income - (dashboard.expenditure + dashboard.investment);

    dispatch({
      type: GET_TRANSACTION,
      payload: {
        Transactions: res.data,
        error: false,
        loading: false,
        dashboard,
      },
    });
  } catch (e) {
    dispatch({
      type: GET_TRANSACTION,
      payload: {
        Transactions: [],
        error: true,
        loading: false,
      },
    });
  }
};

export const filterTransactions = (type: string) => async (dispatch: any) => {
  if (type === "all") {
    dispatch(getTransactions());
  } else {
    try {
      const res = await axios.get(
        `https://json-mock-server8.herokuapp.com/Transactions?TransactionType=${type}`
      );

      console.log(res);
      dispatch({
        type: FILTER_TRANSACTION,
        payload: {
          Transactions: res.data,
          error: false,
          loading: false,
        },
      });
    } catch (e) {
      dispatch({
        type: FILTER_TRANSACTION,
        payload: {
          error: true,
          loading: false,
        },
      });
    }
  }
};
