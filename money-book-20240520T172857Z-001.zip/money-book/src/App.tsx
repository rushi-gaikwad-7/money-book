import "./App.css";
import { NavigationBar } from "./layout/navigationBar";
import { Homepage } from "./pages/homepage";

function App() {
  return (
    <div className="App">
      <NavigationBar />
      <Homepage />
    </div>
  );
}

export default App;
