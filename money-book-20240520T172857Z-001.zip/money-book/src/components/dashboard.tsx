import { Box, Typography } from "@mui/material";
import { useSelector } from "react-redux";
import { initStateType } from "../types/redux.types";

export const DashBoard = () => {
  const { dashboard } = useSelector((state: initStateType) => state);

  return (
    <>
      <Box
        sx={{
          display: "flex",
          padding: "20px",
          justifyContent: "center",
          gap: "60px",
          margin: "10px 10px",
        }}
      >
        <Box
          sx={{
            padding: "25px 0px",
            width: "300px",
            borderRadius: "30px 50px",
            background: "lightgreen",
            boxShadow:
              "rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset",
          }}
        >
          <img
            width="40px"
            style={{ marginBottom: "10px" }}
            src="https://cdn-icons-png.flaticon.com/512/3135/3135706.png"
            alt="img"
          />
          <Typography fontSize={25}>INCOME/PROFIT</Typography>
          <Typography fontWeight="bold" fontSize={20}>
            {dashboard.income} ₹
          </Typography>
        </Box>
        <Box
          sx={{
            padding: "25px",
            width: "250px",
            borderRadius: "30px 50px",
            background: "#ef99ff",
            boxShadow:
              "rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset",
          }}
        >
          <img
            width="40px"
            style={{ marginBottom: "10px" }}
            src="https://cdn-icons-png.flaticon.com/512/2510/2510702.png"
            alt="img"
          />
          <Typography fontSize={25}>INVESTMENT/SAVING</Typography>
          <Typography fontWeight="bold" fontSize={20}>
            {dashboard.investment} ₹
          </Typography>
        </Box>
        <Box
          sx={{
            padding: "25px",
            width: "250px",
            borderRadius: "30px 50px",
            background: "#FF2400",
            boxShadow:
              "rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset",
          }}
        >
          <img
            width="40px"
            style={{ marginBottom: "10px" }}
            src="https://cdn-icons-png.flaticon.com/512/5501/5501375.png"
            alt="img"
          />
          <Typography fontSize={25}>EXPENDITURE</Typography>
          <Typography fontWeight="bold" fontSize={20}>
            {dashboard.expenditure} ₹
          </Typography>
        </Box>
      </Box>
    </>
  );
};
