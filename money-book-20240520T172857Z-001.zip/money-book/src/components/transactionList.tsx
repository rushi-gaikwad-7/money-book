import { ListItem } from "@mui/material";
import List from "@mui/material/List";
import Typography from "@mui/material/Typography";
import { Box } from "@mui/system";
import { useSelector } from "react-redux";
import { initStateType } from "../types/redux.types";
import { dataType } from "../types/transaction.types";
import { Loading } from "../utils/loading";

export const TransactionList = () => {
  const { Transactions, error, loading } = useSelector(
    (state: initStateType) => state
  );

  const Data: dataType[] = Transactions;

  return (
    <>
      {loading ? (
        <Loading />
      ) : (
        <>
          {Transactions.length > 0 ? (
            <>
              <List
                sx={{
                  width: "100%",
                  maxWidth: 750,
                  bgcolor: "background.paper",
                  position: "relative",
                  overflow: "auto",
                  maxHeight: 300,
                  "& ul": { padding: 2 },
                }}
                subheader={<li />}
              >
                <ul>
                  {Data &&
                    Data.map((item) => (
                      <Box key={item.id}>
                        <ListItem
                          style={{
                            marginBottom: "10px",
                            display: "flex",
                            justifyContent: "space-between",
                            boxShadow:
                              "rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px",
                          }}
                          key={`${item.id}`}
                        >
                          <Typography
                            width={150}
                            fontWeight="bold"
                            fontSize={15}
                          >
                            {item.TransactionLabel.toLocaleUpperCase()}
                          </Typography>
                          <Typography fontSize={12}>
                            {new Date(item.Date).toDateString()}
                            <br />
                            {new Date(item.Date).toLocaleTimeString()}
                          </Typography>
                          <Typography
                            width={100}
                            fontWeight="bold"
                            fontSize={18}
                          >
                            {item.Amount} ₹
                          </Typography>
                        </ListItem>
                      </Box>
                    ))}
                </ul>
              </List>
            </>
          ) : (
            <>
              <img
                width="140px"
                style={{ marginTop: "50px" }}
                src="https://cdn-icons-png.flaticon.com/512/4826/4826311.png"
                alt="img"
              />
              <p> Transaction box is empty</p>
            </>
          )}
        </>
      )}
    </>
  );
};
