import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import Box from "@mui/material/Box";
import { useState } from "react";
import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import { Button, Input, InputAdornment } from "@mui/material";
import { TransactionObj } from "../types/transaction.types";
import { useDispatch } from "react-redux";
import { AppDispatch, initStateType } from "../types/redux.types";
import { addNewTransaction } from "../redux/actions/transaction.action";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useSelector } from "react-redux";

export const InputForm = () => {
  const notify = (text: string) => toast(text);

  const useAppDispatch: () => AppDispatch = useDispatch;

  const { dashboard } = useSelector((state: initStateType) => state);

  const dispatch = useAppDispatch();
  const [transaction, setTransaction] = useState<TransactionObj>({
    TransactionType: "income",
    Amount: "",
    TransactionLabel: "",
  });

  const handleSubmit = () => {
    if (transaction.Amount === "") {
      notify("Please enter the amount");
    } else if (transaction.TransactionLabel === "") {
      notify("Please enter the transaction label");
    } else if (
      +transaction.Amount > dashboard.current_balance &&
      transaction.TransactionType !== "income"
    ) {
      notify("Insufficient Balance");
    } else {
      dispatch(addNewTransaction(transaction, notify));
      setTransaction({
        TransactionType: "income",
        Amount: "",
        TransactionLabel: "",
      });
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        p: 1,
        m: 1,
        bgcolor: "snow",
        borderRadius: 1,
      }}
    >
      <ToastContainer
        position="top-right"
        autoClose={1500}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="dark"
      />
      <ToggleButtonGroup
        value={transaction.TransactionType}
        exclusive
        onChange={(e) =>
          setTransaction({
            ...transaction,
            TransactionType: (e.target as HTMLInputElement).value,
          })
        }
        aria-label="Platform"
      >
        <ToggleButton color="success" value="income">
          INCOME/PROFIT
        </ToggleButton>
        <ToggleButton color="secondary" value="investment">
          INVESTMENT/SAVING
        </ToggleButton>
        <ToggleButton color="error" value="expenditure">
          EXPENDITURE
        </ToggleButton>
      </ToggleButtonGroup>
      <FormControl fullWidth sx={{ m: 1, width: "100%" }} variant="standard">
        <InputLabel htmlFor="standard-adornment-amount"> Amount</InputLabel>
        <Input
          type="number"
          onFocus={(e) =>
            e.target.addEventListener(
              "wheel",
              function (e) {
                e.preventDefault();
              },
              { passive: false }
            )
          }
          inputMode="numeric"
          id="standard-adornment-amount"
          onKeyDown={(e) =>
            ["e", "E", "+", "-"].includes(e.key) && e.preventDefault()
          }
          value={transaction.Amount}
          onChange={(e) =>
            setTransaction({
              ...transaction,
              Amount: (e.target as HTMLInputElement).value,
            })
          }
          startAdornment={<InputAdornment position="start">₹</InputAdornment>}
        />
      </FormControl>
      <Input
        sx={{ m: 1, width: "100%" }}
        placeholder="Enter transaction details"
        value={transaction.TransactionLabel}
        spellCheck
        onChange={(e) =>
          setTransaction({
            ...transaction,
            TransactionLabel: (e.target as HTMLInputElement).value,
          })
        }
      />
      <Button
        onClick={() => handleSubmit()}
        sx={{ m: 1, width: "100%" }}
        variant="contained"
        color="primary"
      >
        ADD
      </Button>
    </Box>
  );
};
