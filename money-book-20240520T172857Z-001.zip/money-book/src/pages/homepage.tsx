import {
  Box,
  FormControl,
  FormControlLabel,
  Radio,
  RadioGroup,
  Typography,
} from "@mui/material";
import { DashBoard } from "../components/dashboard";
import { InputForm } from "../components/inputForm";
import { TransactionList } from "../components/transactionList";
import { useEffect } from "react";
import { AppDispatch, initStateType } from "../types/redux.types";
import { useDispatch } from "react-redux";
import {
  filterTransactions,
  getTransactions,
} from "../redux/actions/transaction.action";
import { useSelector } from "react-redux";



export const Homepage = () => {
  const useAppDispatch: () => AppDispatch = useDispatch;

  const handleFilter = (e: { target: { value: string } }) => {
    dispatch(filterTransactions(e.target.value));
  };

  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(getTransactions());
  }, []);

  return (
    <>
      <DashBoard />
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          gap: "30px",
          boxSizing: "border-box",
          marginTop: "20px",
          padding: "30px 0px",
          minHeight: "300px",
        }}
      >
        <Box
          sx={{
            width: "50%",
            boxSizing: "border-box",
            padding: "20px 0px",
            boxShadow:
              "rgba(60, 64, 67, 0.3) 0px 1px 2px 0px, rgba(60, 64, 67, 0.15) 0px 1px 3px 1px",
          }}
        >
          <Typography marginBottom="10px" color="blue" fontSize={25}>
            TRANSACTIONS
          </Typography>
          <FormControl>
            <RadioGroup
              onChange={(e) => handleFilter(e)}
              row
              aria-labelledby="demo-row-radio-buttons-group-label"
              name="row-radio-buttons-group"
            >
              <FormControlLabel value="all" control={<Radio />} label="All" />
              <FormControlLabel
                value="income"
                control={<Radio color="success" />}
                label="Income/Profit"
              />
              <FormControlLabel
                value="investment"
                control={<Radio color="secondary" />}
                label="Investment/Saving"
              />
              <FormControlLabel
                value="expenditure"
                control={<Radio color="error" />}
                label="Expenditure"
              />
            </RadioGroup>
          </FormControl>
          <TransactionList />
        </Box>

        <Box
          sx={{
            padding: "10px",
            borderRadius: "25px",
            height: "280px",
            boxShadow:
              "rgba(0, 0, 0, 0.4) 0px 2px 4px, rgba(0, 0, 0, 0.3) 0px 7px 13px -3px, rgba(0, 0, 0, 0.2) 0px -3px 0px inset",
          }}
        >
          <Typography color="blue" fontSize={25}>
            ADD TRANSACTION
          </Typography>
          <InputForm />
        </Box>
      </Box>
    </>
  );
};
