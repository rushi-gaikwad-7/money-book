import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import { useSelector } from "react-redux";
import { initStateType } from "../types/redux.types";

export const NavigationBar = () => {
  const { dashboard } = useSelector((state: initStateType) => state);
  return (
    <Box
      sx={{
        flexGrow: 1,
      }}
    >
      <AppBar position="static">
        <Box
          sx={{
            display: "flex",
            padding: "10px 20px",
            justifyContent: "space-between",
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <img
              style={{ marginLeft: "10px" }}
              width={60}
              src="https://cdn-icons-png.flaticon.com/512/3029/3029373.png"
              alt=""
            />
            <Toolbar>
              <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                🅼🅾🅽🅴🆈🅱🅾🅾🅺
              </Typography>
            </Toolbar>
          </Box>
          <Box
            sx={{
              boxSizing: "border-box",
              padding: "10px",
              borderRadius: "10px",
              backgroundColor: "skyblue",
              color: "black",
              boxShadow:
                "rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px, rgba(10, 37, 64, 0.35) 0px -2px 6px 0px inset",
            }}
          >
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
              }}
            >
              <img
                width="30px"
                src="https://cdn-icons-png.flaticon.com/512/8133/8133788.png"
                alt="img"
              />
              <Typography
                sx={{ marginLeft: "10px" }}
                fontWeight="bold"
                fontSize={25}
              >
                {dashboard.current_balance} ₹
              </Typography>
            </Box>
            <Typography fontSize={15}>BALANCE</Typography>
          </Box>
        </Box>
      </AppBar>
    </Box>
  );
};
