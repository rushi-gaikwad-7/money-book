import { Store } from "../redux/store";

export type AppDispatch = typeof Store.dispatch;

export interface initStateType {
  Transactions: [];
  error: boolean;
  loading: boolean;
  dashboard: dashboardData;
}

export interface dashboardData {
  income: number;
  investment: number;
  expenditure: number;
  current_balance: number;
}
