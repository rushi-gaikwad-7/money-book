export interface TransactionObj {
  Amount: string;
  TransactionType: string;
  TransactionLabel: string;
}

export interface resType {
  Amount: string;
  TransactionType: string;
  TransactionLabel: string;
  Date: string;
}

export interface dataType {
  TransactionType: string;
  Amount: string;
  TransactionLabel: string;
  Date: Date;
  id: number;
}
